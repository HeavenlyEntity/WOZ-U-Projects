Insert INTO ProductList (ProductName, Price, EmployeeSupportId)
Values ("The Best Moms Of America eBook", 10.99, 6);
