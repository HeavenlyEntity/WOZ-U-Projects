select * from customers 
where State IN ("Asia","Europe","South America");
