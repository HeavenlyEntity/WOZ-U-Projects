select * from tracks 
where Composer IS NULL