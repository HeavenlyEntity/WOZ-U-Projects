Insert INTO employees (FirstName, LastName, BirthDate, HireDate, City, State, Country, Phone, Email)
Values ("Jim", "Perkins", "November 12, 1984", "April 10, 2012" ,"Glendale", "AZ", "USA", "623-781-2562", "jimmyperks@yahoo.com");
