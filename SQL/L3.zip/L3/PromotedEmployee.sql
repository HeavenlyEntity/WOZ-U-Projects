UPDATE employees
SET Title = "Floor Manager", ReportsTo = "2"
where EmployeeId = "9"
