
UPDATE customers
SET State = "Europe"
Where country IN ("Germany", "Norway", "Czech Republic", "Portugal","Denmark", "Belgium", "Austria", "France", "Finland", "Hungary", "Poland", "Spain", "Sweden", "United Kingdom");