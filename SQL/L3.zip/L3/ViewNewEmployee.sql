Select * from employees
where FirstName = "Jim"
