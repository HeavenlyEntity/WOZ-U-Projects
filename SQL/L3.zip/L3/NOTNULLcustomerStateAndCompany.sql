select * from customers 
where State IS NOT NULL AND Company IS NOT NULL;