Delete from customers 
where country = "United Kingdom";

Insert INTO customers (FirstName, LastName, City, Country, Phone, Email, SupportRepId)
Values ("Maxium","Gustouvich","Moscow","Russia","012-888-7452","skatehardordiehard@gmail.com","6"), 
            ("June","Vuchstoche","Moscow","Russia","012-626-3150","thehotmessness@gmail.com","6"), 
                ("Christopher","Ukezniska","Voronezh","Russia","012-789-6523","theEthicalHacker@gmail.com","6");

