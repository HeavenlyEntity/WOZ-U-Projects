select * from customers 
where State IS NULL AND Company IS NULL;