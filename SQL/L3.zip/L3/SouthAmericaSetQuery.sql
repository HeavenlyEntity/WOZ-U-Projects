
UPDATE customers
SET State = "South America"
Where country IN ("Chile", "Argentina");