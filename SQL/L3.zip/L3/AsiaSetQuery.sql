
UPDATE customers
SET State = "Asia"
Where country = "India"