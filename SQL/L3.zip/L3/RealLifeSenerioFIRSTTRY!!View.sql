select * from customers 
where Country IN ("Russia", "United Kingdom");
