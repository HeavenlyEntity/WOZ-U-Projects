SELECT * FROM tracks
WHERE Name LIKE "a%";