SELECT * FROM playlists
WHERE Name NOT LIKE "%Music%" AND "%Movies%" ;