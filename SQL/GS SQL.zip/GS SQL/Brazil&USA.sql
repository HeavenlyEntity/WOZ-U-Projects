SELECT FirstName, LastName, Phone, Fax, Email FROM customers
WHERE Country = "USA" OR Country = "Brazil";