SELECT * FROM tracks
WHERE AlbumId < 340 AND AlbumId > 240;