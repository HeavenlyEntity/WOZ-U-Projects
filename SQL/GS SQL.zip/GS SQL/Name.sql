SELECT * FROM customers
WHERE FirstName LIKE "Jennifer%";
