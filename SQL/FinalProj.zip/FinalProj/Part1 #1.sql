UPDATE * from tracks
Set 
INNER Join albums USING (AlbumId)
Where AlbumId = 8
OR AlbumId = 21
 OR AlbumId = 22 
  OR AlbumId = 23
   OR AlbumId = 24
    OR AlbumId = 25
     OR AlbumId = 26
      OR AlbumId = 27
       OR AlbumId = 28
        OR AlbumId = 29
         OR AlbumId = 32
          OR AlbumId = 33
           OR AlbumId = 34
            OR AlbumId = 41
             OR AlbumId = 42
              OR AlbumId = 45
               OR AlbumId = 47
                OR AlbumId = 52
                 OR AlbumId = 53
  